## Description
<!-- Provide a brief description of your changes -->

## Type of Change
- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to change)
- [ ] Addon/Extension
- [ ] Documentation

## Testing
- [ ] I have tested these changes locally
- [ ] I have added/updated unit tests
- [ ] All tests pass (`./gradlew test`)

## Checklist
- [ ] My code follows the project's code style
- [ ] I have updated the documentation (if needed)
- [ ] I have added changelog entry (if this is a feature/fix)
- [ ] No new warnings are introduced
- [ ] This PR is for the `fabric-1.21.4-port` branch (or related branch)

## Related Issue
<!-- Link to any related issues: fixes #123 -->

## Notes
<!-- Any additional information for reviewers -->

---

### For Addon Developers
If you're submitting an addon:
- [ ] Addon implements the `Addon` interface
- [ ] Addon ID follows format `namespace:name`
- [ ] Addon has a service loader entry in `META-INF/services/com.magistuarmory.addon.Addon`
- [ ] Example code is included and documented
- [ ] Addon handles errors gracefully

### Build & Test Verification
Before submitting, verify:
```bash
./gradlew clean build      # Full build
./gradlew test             # Run unit tests
./gradlew runClient        # Test in game (if applicable)
```
