package com.magistuarmory.client.render.model.item;
// Made with Blockbench 4.3.1
// Exported for Minecraft version 1.17 - 1.18 with Mojang mappings
// Paste this class into your mod and generate all required imports


import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;

@Environment(EnvType.CLIENT)
public class CorruptedRoundShieldModel extends MedievalShieldModel 
{
	public CorruptedRoundShieldModel(ModelPart root) 
	{
		super(root);
	}

	public static LayerDefinition createLayer() 
	{
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		partdefinition.addOrReplaceChild("plate", CubeListBuilder.create().texOffs(0, 0).addBox(-15.5F, -17.0F, -2.0F, 31.0F, 32.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 60).addBox(-3.5F, 4.0F, -2.0F, 7.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(10, 58).addBox(-5.5F, 3.0F, -2.0F, 11.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(9, 55).addBox(-6.5F, 1.0F, -2.0F, 13.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(3, 52).addBox(-7.5F, -1.0F, -2.0F, 4.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(3, 47).addBox(-7.5F, -5.0F, -2.0F, 3.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(3, 45).addBox(-7.5F, -6.0F, -2.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(13, 51).addBox(-2.5F, -2.0F, -2.0F, 10.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(19, 49).addBox(-3.5F, -3.0F, -2.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(19, 47).addBox(-3.5F, -4.0F, -2.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(20, 44).addBox(-2.5F, -6.0F, -2.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(29, 47).addBox(0.5F, -5.0F, -2.0F, 7.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(25, 44).addBox(0.5F, -7.0F, -2.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(31, 45).addBox(2.5F, -6.0F, -2.0F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(31, 42).addBox(2.5F, -8.0F, -2.0F, 4.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(30, 40).addBox(1.5F, -9.0F, -2.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(30, 38).addBox(1.5F, -10.0F, -2.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 2.0F, 0.0F));
		partdefinition.addOrReplaceChild("handle", CubeListBuilder.create().texOffs(48, 52).addBox(-1.0F, -3.0F, -1.0F, 2.0F, 6.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}
}